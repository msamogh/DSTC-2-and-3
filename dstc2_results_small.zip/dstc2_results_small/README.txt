dstc2_results_small

- all.csv lists all the calculated metrics for each system
- featured.csv lists the featured metrics
- all_descriptions.txt gives some information about each tracker

- The full download, available at http://camdial.org/~mh521/dstc/ includes for each entry:
    - a .txt file, giving some more information about the approach used
    - a .test.json file, giving the output of the tracker on the test set
    - a .test.score.csv file, giving the scores on the test set
    - a .dev.score.csv file, giving the scores on the dev set
    
- The full download provides a python script which allows you to recalculate the test scores yourself.